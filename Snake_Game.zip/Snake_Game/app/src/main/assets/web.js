
    const canvas = document.getElementById('canvas')
    const ctx = canvas.getContext('2d')



    // this creates the start screen
    function myFunction()
    {


            // used to record last length of the snake
            var lastLength = 0;

            // set score up
            var score = 0;

            //used to pause the game?
            var died = 0;

            //load image
            const foodImg = new Image();
            foodImg.src = "food.png";

            const snakeImg = new Image();
            snakeImg.src = "pepe.png";

            const sovietImg = new Image();
            sovietImg.src = "soviet.png";

            const gameOver = new Image();
            gameOver.src = "gameover.jpg";

            //load audio and assign files to names
            let dead = new Audio();
            let eat = new Audio();
            let annoy = new Audio();
            let gg = new Audio();

            dead.src = "audio/dead.mp3";
            eat.src = "audio/eat.mp3";
            annoy.src = "audio/annoy.mp3";
            gg.src = "audio/moti.mp3";



            // this is what activates the progress bar it was originally meant to be used for score
            function move()
            {
              var elem = document.getElementById("myBar");
              var width = 1;
              var id = setInterval(frame, 1);
              function frame()
              {
                if (width >= 100)
                {
                  clearInterval(id);
                }
                 else
                {
                  width++;
                  elem.style.width = width + '%';
                  elem.innerHTML = width * 1 + '%';
                }
              }
            }

            //  this should draw the score to the screen
            function drawScore()
            {
                ctx.font = "16px Arial";
                ctx.fillStyle = "#0095DD";
                ctx.fillText("Score: " + score, 8, 20);
            }

            function splashIO (event)
            {  // function to start the game when IO is correct
                // check for the correct events
                if(event.type === "click" || (event.type === "keydown" && event.code === "Enter")){
                     // remove events
                     canvas.removeEventListener("click",splashIO);
                     canvas.removeEventListener("keydown",splashIO);
                     gameStates.current = gameStates.startGame;

                     score = new component("30px", "Console", "black", 280, 40, "text");
                }
            }

            // Mutable state
            let state = initialState()

            // Position helpers
            const x = c => Math.round(c * canvas.width / state.cols)
            const y = r => Math.round(r * canvas.height / state.rows)

            // Game loop draw
            const draw = () =>
            {

                if(state.snake.length > 0)
                {
                  // fill background with image
                  var pat=ctx.createPattern(sovietImg,"repeat");
                  ctx.rect(0, 0, canvas.width, canvas.height);
                  ctx.fillStyle=pat;
                  ctx.fill();

                  // draw snake
                  ctx.fillStyle = 'rgb(0,200,50)'
                  state.snake.map(p => ctx.fillRect(x(p.x), y(p.y), x(1), y(1)));
                  state.snake.map(p => ctx.drawImage(snakeImg, x(p.x), y(p.y), x(1), y(1)));

                  // draw apple
                  ctx.fillStyle = 'rgb(255,255,0)'
                  ctx.fillRect(x(state.apple.x), y(state.apple.y), x(1), y(1));
                  ctx.drawImage(foodImg, x(state.apple.x), y(state.apple.y), x(1), y(1));

                  // actually draw the score
                  drawScore();

                }
              // add crash, checks length of snake to see if dead or an action needs to happen
              if (state.snake.length == 0)
              {
              //when the snake dies this is meant to wait for a key press to allow the game to start again
                  if (died = 1)
                  {
                    //somehow in the code this section is always accessed at the start of the game as noted by the audio
                    //this just draws the game over screen
                      var pat=ctx.createPattern(gameOver,"repeat");
                      ctx.rect(0, 0, canvas.width, canvas.height);
                      ctx.fillStyle=pat;
                      ctx.fill();
                      //make sure score is visable
                      drawScore();
                      //play mp3
                      gg.play();
                      //reset death
                      died--;
                  }
              }

              //if snake is bigger aka it ate then score increment, sound play, update lastlength
              if (state.snake.length > lastLength)
              {
                score++;
                move();
                eat.play();
                lastLength++;
              }
              //if no change then play sounds
              if(state.snake.length = lastLength)
              {
                // annoying sound
                annoy.play();
              }
              //if died the play sounds, set died to true
              if(state.snake.length < lastLength)
              {
                died++;
                //gg.play();
              }
            }

            // Game loop update
            const step = t1 => t2 =>
            {
              if (t2 - t1 > 100)
              {
                state = next(state)
                draw()

                window.requestAnimationFrame(step(t2))
              }
              else
              {
                window.requestAnimationFrame(step(t1))
              }
            }



            // Key events
            window.addEventListener('keydown', e =>
            {
              switch (e.key)
              {
                case 'w': case 'h': case 'ArrowUp':    state = enqueue(state, NORTH); break
                case 'a': case 'j': case 'ArrowLeft':  state = enqueue(state, WEST);  break
                case 's': case 'k': case 'ArrowDown':  state = enqueue(state, SOUTH); break
                case 'd': case 'l': case 'ArrowRight': state = enqueue(state, EAST);  break
            }
            })

            // Main
            draw(); window.requestAnimationFrame(step(0))


    }

    /* couldn't get touch controls working
    //touch event listener
        canvas.addEventListener("touchmove", touchXY, true);

        function touchXY(evt)
        {
        evt.preventDefault();
        if(lastPt!=null) {
        var touchX = evt.touches[0].pageX - canvas.offsetLeft;
        var touchY = evt.touches[0].pageY - canvas.offsetTop;
        }
        lastPt = {x:evt.touches[0].pageX, y:evt.touches[0].pageY};
        }

        var lastPt=null;
    */
    /*
          //touch movement maths
              if (snake.position.x + lastPt.x > snake.position.y + lastPt.y)
              {
              if (snake.position.x > lastPt.x)
              {
                  state = enqueue(state, East);
              }
              else
              {
                  state = enqueue(state, WEST);
              }
              }
              if (snake.position.x + lastPt.x < snake.position.y + lastPt.y)
                  {
                  if (snake.position.y > lastPt.y)
                  {
                      state = enqueue(state, SOUTH);
                  }
                  else
                  {
                      state = enqueue(state, NORTH);
                  }
                  }
        }
*/